package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recently_played")
data class RecentlyPlayedEntity(
    @PrimaryKey val mediaPath: String,
    val title: String,
    val duration: Long,
    val lastProgress: Long,
    val isVideo: Boolean,
    val lastPlayedTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val mediaPath: String,
    val title: String,
    val isVideo: Boolean,
    val addedTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String = "",
    val createdTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_items")
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val mediaPath: String,
    val title: String,
    val isVideo: Boolean,
    val addedTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "private_media")
data class PrivateMediaEntity(
    @PrimaryKey val mediaPath: String,
    val originalPath: String,
    val title: String,
    val isVideo: Boolean,
    val hiddenTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "vault_config")
data class VaultConfigEntity(
    @PrimaryKey val key: String, // e.g. "pin"
    val value: String // stored PIN
)
