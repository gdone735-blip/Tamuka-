package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MediaDao {

    // --- Recently Played ---
    @Query("SELECT * FROM recently_played ORDER BY lastPlayedTime DESC")
    fun getRecentlyPlayedFlow(): Flow<List<RecentlyPlayedEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentlyPlayed(entity: RecentlyPlayedEntity)

    @Query("DELETE FROM recently_played WHERE mediaPath = :mediaPath")
    suspend fun deleteRecentlyPlayed(mediaPath: String)

    @Query("DELETE FROM recently_played")
    suspend fun clearHistory()


    // --- Favorites ---
    @Query("SELECT * FROM favorites ORDER BY addedTime DESC")
    fun getFavoritesFlow(): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE mediaPath = :mediaPath)")
    fun isFavoriteFlow(mediaPath: String): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE mediaPath = :mediaPath)")
    suspend fun isFavorite(mediaPath: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(entity: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE mediaPath = :mediaPath")
    suspend fun deleteFavorite(mediaPath: String)


    // --- Playlists ---
    @Query("SELECT * FROM playlists ORDER BY name ASC")
    fun getPlaylistsFlow(): Flow<List<PlaylistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(entity: PlaylistEntity): Long

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deletePlaylist(id: Long)


    // --- Playlist Items ---
    @Query("SELECT * FROM playlist_items WHERE playlistId = :playlistId ORDER BY addedTime DESC")
    fun getPlaylistItemsFlow(playlistId: Long): Flow<List<PlaylistItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistItem(entity: PlaylistItemEntity)

    @Query("DELETE FROM playlist_items WHERE playlistId = :playlistId AND mediaPath = :mediaPath")
    suspend fun deletePlaylistItem(playlistId: Long, mediaPath: String)

    @Query("DELETE FROM playlist_items WHERE playlistId = :playlistId")
    suspend fun deletePlaylistItemsForPlaylist(playlistId: Long)


    // --- Private Vault Folder ---
    @Query("SELECT * FROM private_media ORDER BY hiddenTime DESC")
    fun getPrivateMediaFlow(): Flow<List<PrivateMediaEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrivateMedia(entity: PrivateMediaEntity)

    @Query("DELETE FROM private_media WHERE mediaPath = :mediaPath")
    suspend fun deletePrivateMedia(mediaPath: String)

    @Query("SELECT EXISTS(SELECT 1 FROM private_media WHERE mediaPath = :mediaPath)")
    suspend fun isPrivate(mediaPath: String): Boolean


    // --- Vault Config (PIN lock) ---
    @Query("SELECT value FROM vault_config WHERE `key` = :key LIMIT 1")
    suspend fun getConfigValue(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfig(entity: VaultConfigEntity)
}
