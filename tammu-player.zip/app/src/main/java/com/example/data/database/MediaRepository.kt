package com.example.data.database

import kotlinx.coroutines.flow.Flow

class MediaRepository(private val mediaDao: MediaDao) {

    // --- Recently Played (History & Progress Resume) ---
    val recentlyPlayed: Flow<List<RecentlyPlayedEntity>> = mediaDao.getRecentlyPlayedFlow()

    suspend fun insertRecentlyPlayed(path: String, title: String, duration: Long, progress: Long, isVideo: Boolean) {
        val entity = RecentlyPlayedEntity(
            mediaPath = path,
            title = title,
            duration = duration,
            lastProgress = progress,
            isVideo = isVideo,
            lastPlayedTime = System.currentTimeMillis()
        )
        mediaDao.insertRecentlyPlayed(entity)
    }

    suspend fun deleteRecentlyPlayed(path: String) {
        mediaDao.deleteRecentlyPlayed(path)
    }

    suspend fun clearHistory() {
        mediaDao.clearHistory()
    }


    // --- Favorites ---
    val favorites: Flow<List<FavoriteEntity>> = mediaDao.getFavoritesFlow()

    fun isFavoriteFlow(path: String): Flow<Boolean> = mediaDao.isFavoriteFlow(path)

    suspend fun isFavorite(path: String): Boolean = mediaDao.isFavorite(path)

    suspend fun addFavorite(path: String, title: String, isVideo: Boolean) {
        val entity = FavoriteEntity(
            mediaPath = path,
            title = title,
            isVideo = isVideo,
            addedTime = System.currentTimeMillis()
        )
        mediaDao.insertFavorite(entity)
    }

    suspend fun removeFavorite(path: String) {
        mediaDao.deleteFavorite(path)
    }


    // --- Playlists ---
    val playlists: Flow<List<PlaylistEntity>> = mediaDao.getPlaylistsFlow()

    suspend fun createPlaylist(name: String, description: String = ""): Long {
        val entity = PlaylistEntity(name = name, description = description)
        return mediaDao.insertPlaylist(entity)
    }

    suspend fun deletePlaylist(playlistId: Long) {
        mediaDao.deletePlaylistItemsForPlaylist(playlistId)
        mediaDao.deletePlaylist(playlistId)
    }


    // --- Playlist Items ---
    fun getPlaylistItems(playlistId: Long): Flow<List<PlaylistItemEntity>> = 
        mediaDao.getPlaylistItemsFlow(playlistId)

    suspend fun addPlaylistItem(playlistId: Long, path: String, title: String, isVideo: Boolean) {
        val entity = PlaylistItemEntity(
            playlistId = playlistId,
            mediaPath = path,
            title = title,
            isVideo = isVideo,
            addedTime = System.currentTimeMillis()
        )
        mediaDao.insertPlaylistItem(entity)
    }

    suspend fun removePlaylistItem(playlistId: Long, path: String) {
        mediaDao.deletePlaylistItem(playlistId, path)
    }


    // --- Private Vault Folder ---
    val privateMedia: Flow<List<PrivateMediaEntity>> = mediaDao.getPrivateMediaFlow()

    suspend fun addPrivateMedia(path: String, originalPath: String, title: String, isVideo: Boolean) {
        val entity = PrivateMediaEntity(
            mediaPath = path,
            originalPath = originalPath,
            title = title,
            isVideo = isVideo,
            hiddenTime = System.currentTimeMillis()
        )
        mediaDao.insertPrivateMedia(entity)
    }

    suspend fun removePrivateMedia(path: String) {
        mediaDao.deletePrivateMedia(path)
    }

    suspend fun isPrivate(path: String): Boolean = mediaDao.isPrivate(path)


    // --- Vault Configuration (PIN) ---
    suspend fun getVaultPin(): String? {
        return mediaDao.getConfigValue("vault_pin")
    }

    suspend fun setVaultPin(pin: String) {
        mediaDao.insertConfig(VaultConfigEntity("vault_pin", pin))
    }
}
