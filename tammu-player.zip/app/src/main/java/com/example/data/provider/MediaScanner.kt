package com.example.data.provider

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.example.data.model.MediaItem

object MediaScanner {

    // Curated high-fidelity video streams for live testing
    val streamingVideos = listOf(
        MediaItem(
            title = "Big Buck Bunny (Full HD)",
            path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            duration = 596000,
            size = 27613494,
            isVideo = true,
            folderName = "Streaming Videos",
            artist = "Blender Foundation",
            isOnline = true
        ),
        MediaItem(
            title = "Tears of Steel (Sci-Fi 4K)",
            path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
            duration = 734000,
            size = 48512948,
            isVideo = true,
            folderName = "Streaming Videos",
            artist = "Blender VFX Team",
            isOnline = true
        ),
        MediaItem(
            title = "Sintel (Fantasy Drama)",
            path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
            duration = 888000,
            size = 38512900,
            isVideo = true,
            folderName = "Streaming Videos",
            artist = "Durian Open Movie Project",
            isOnline = true
        ),
        MediaItem(
            title = "Elephants Dream (Classic)",
            path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            duration = 653000,
            size = 32512900,
            isVideo = true,
            folderName = "Streaming Videos",
            artist = "Orange Open Movie Project",
            isOnline = true
        )
    )

    // Curated high-fidelity music streams for live testing
    val streamingMusic = listOf(
        MediaItem(
            title = "Synthwave Cruise (SoundHelix-1)",
            path = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            duration = 372000,
            size = 8900000,
            isVideo = false,
            folderName = "Streaming Music",
            artist = "SoundHelix Band",
            album = "Helix Retro Waves",
            isOnline = true
        ),
        MediaItem(
            title = "Cyberpunk Neon (SoundHelix-2)",
            path = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
            duration = 425000,
            size = 10200000,
            isVideo = false,
            folderName = "Streaming Music",
            artist = "SoundHelix Band",
            album = "Helix Cyber Odyssey",
            isOnline = true
        ),
        MediaItem(
            title = "Acoustic Chill (SoundHelix-4)",
            path = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
            duration = 302000,
            size = 7200000,
            isVideo = false,
            folderName = "Streaming Music",
            artist = "SoundHelix Band",
            album = "Helix Acoustic Sessions",
            isOnline = true
        ),
        MediaItem(
            title = "Electro Punch Beat (SoundHelix-8)",
            path = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
            duration = 318000,
            size = 7600000,
            isVideo = false,
            folderName = "Streaming Music",
            artist = "SoundHelix Band",
            album = "Helix Electronic Vibes",
            isOnline = true
        )
    )

    /**
     * Scans local files from MediaStore and merges with online streams.
     */
    fun scanMedia(context: Context): List<MediaItem> {
        val mediaList = mutableListOf<MediaItem>()

        // Add Online Streams first so they are immediately accessible in emulator
        mediaList.addAll(streamingVideos)
        mediaList.addAll(streamingMusic)

        // Try reading local videos from MediaStore
        try {
            val videoProjection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Video.Media.DATE_ADDED
            )

            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                videoProjection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val bucketColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val name = cursor.getString(nameColumn)
                    val duration = cursor.getLong(durationColumn)
                    val size = cursor.getLong(sizeColumn)
                    val bucket = cursor.getString(bucketColumn) ?: "Internal Storage"
                    val dateAdded = cursor.getLong(dateColumn)
                    val contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id).toString()

                    mediaList.add(
                        MediaItem(
                            title = name,
                            path = contentUri,
                            duration = duration,
                            size = size,
                            isVideo = true,
                            folderName = bucket,
                            dateAdded = dateAdded
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Try reading local audio from MediaStore
        try {
            val audioProjection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DATE_ADDED
            )

            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                audioProjection,
                null,
                null,
                "${MediaStore.Audio.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val name = cursor.getString(nameColumn)
                    val duration = cursor.getLong(durationColumn)
                    val size = cursor.getLong(sizeColumn)
                    val artist = cursor.getString(artistColumn) ?: "Unknown Artist"
                    val album = cursor.getString(albumColumn) ?: "Unknown Album"
                    val dateAdded = cursor.getLong(dateColumn)
                    val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id).toString()

                    mediaList.add(
                        MediaItem(
                            title = name,
                            path = contentUri,
                            duration = duration,
                            size = size,
                            isVideo = false,
                            folderName = "Music Library",
                            artist = artist,
                            album = album,
                            dateAdded = dateAdded
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return mediaList
    }
}
