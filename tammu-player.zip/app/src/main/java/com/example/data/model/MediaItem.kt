package com.example.data.model

data class MediaItem(
    val title: String,
    val path: String, // File path or HTTP stream URL
    val duration: Long = 0, // Milliseconds
    val size: Long = 0, // Bytes
    val isVideo: Boolean,
    val folderName: String = "",
    val artist: String = "Unknown Artist",
    val album: String = "Unknown Album",
    val dateAdded: Long = 0,
    val isOnline: Boolean = false
) {
    val sizeFormatted: String
        get() {
            if (isOnline) return "Network Stream"
            if (size <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
            if (digitGroups >= units.size) return "$size B"
            return String.format("%.1f %s", size / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
        }

    val durationFormatted: String
        get() {
            if (duration <= 0) return "--:--"
            val seconds = (duration / 1000) % 60
            val minutes = (duration / (1000 * 60)) % 60
            val hours = (duration / (1000 * 60 * 60)) % 24
            return if (hours > 0) {
                String.format("%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format("%02d:%02d", minutes, seconds)
            }
        }
}
