package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stream
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaItem
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceElevated
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MutedText
import com.example.ui.viewmodel.MediaViewModel

@Composable
fun NetworkStreamScreen(
    viewModel: MediaViewModel,
    onPlayVideo: (MediaItem) -> Unit,
    onPlayMusic: (MediaItem) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var streamUrl by remember { mutableStateOf("") }
    var streamTitle by remember { mutableStateOf("") }

    // Curated high-quality open network streams for instant play
    val presetStreams = listOf(
        MediaItem(
            title = "Blender Tears Of Steel (HLS Stream)",
            path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
            isVideo = true,
            isOnline = true,
            folderName = "Network Preset"
        ),
        MediaItem(
            title = "Blender Big Buck Bunny (MP4 Stream)",
            path = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            isVideo = true,
            isOnline = true,
            folderName = "Network Preset"
        ),
        MediaItem(
            title = "Helix Live MP3 Audio Stream",
            path = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            isVideo = false,
            isOnline = true,
            folderName = "Network Preset"
        )
    )

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Network Link Streaming",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text(
                text = "Stream Online Media",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Paste any direct HTTP/HTTPS streaming link (MP4, MKV, HLS M3U8, MP3) to play live with HW acceleration.",
                fontSize = 12.sp,
                color = MutedText
            )

            Spacer(modifier = Modifier.height(16.dp))

            // URL inputs
            OutlinedTextField(
                value = streamTitle,
                onValueChange = { streamTitle = it },
                label = { Text("Stream Title (Optional)", color = MutedText) },
                placeholder = { Text("E.g. My Live TV", color = MutedText) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = Color.Gray,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth().testTag("stream_title_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = streamUrl,
                onValueChange = { streamUrl = it },
                label = { Text("Direct Stream URL", color = MutedText) },
                placeholder = { Text("https://example.com/live.m3u8", color = MutedText) },
                leadingIcon = { Icon(Icons.Default.Link, contentDescription = null, tint = CyberCyan) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = Color.Gray,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth().testTag("stream_url_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (streamUrl.isBlank()) {
                        Toast.makeText(context, "Please enter a valid stream URL!", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    
                    // Simple Sniffer for Video vs Audio
                    val isVideo = streamUrl.contains(".mp4") || 
                                  streamUrl.contains(".m3u8") || 
                                  streamUrl.contains(".mkv") || 
                                  streamUrl.contains("video") ||
                                  streamUrl.contains(".mov")

                    val item = MediaItem(
                        title = streamTitle.ifBlank { "Network Stream" },
                        path = streamUrl,
                        isVideo = isVideo,
                        isOnline = true,
                        artist = "Online Source",
                        folderName = "Network Streams"
                    )

                    if (isVideo) onPlayVideo(item) else onPlayMusic(item)
                },
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("play_stream_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Start Streaming", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "Popular Preset Test Streams",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(presetStreams) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CarbonSurface)
                            .clickable {
                                if (item.isVideo) onPlayVideo(item) else onPlayMusic(item)
                            }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CarbonSurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Stream, null, tint = CyberCyan)
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (item.isVideo) "Streaming Video Source" else "Streaming Audio Source",
                                color = MutedText,
                                fontSize = 11.sp
                            )
                        }

                        Icon(Icons.Default.PlayArrow, null, tint = CyberCyan)
                    }
                }
            }
        }
    }
}
