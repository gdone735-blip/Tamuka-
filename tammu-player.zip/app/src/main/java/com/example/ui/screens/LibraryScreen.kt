package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.database.PlaylistEntity
import com.example.data.model.MediaItem
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceElevated
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MutedText
import com.example.ui.viewmodel.MediaViewModel
import com.example.ui.viewmodel.SortOption
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: MediaViewModel,
    onNavigateToVideo: (MediaItem) -> Unit,
    onNavigateToMusic: (MediaItem) -> Unit,
    onNavigateToVault: () -> Unit,
    onNavigateToStream: () -> Unit,
    onNavigateToAds: () -> Unit
) {
    val context = LocalContext.current
    val searchQuery by viewModel.searchQuery.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()
    val videosList by viewModel.videos.collectAsState()
    val musicList by viewModel.music.collectAsState()
    val playlistsList by viewModel.playlists.collectAsState()
    val favoritesList by viewModel.favorites.collectAsState()
    val currentMedia by viewModel.currentMediaItem.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Videos", "Music", "Folders", "Playlists")

    var showPlaylistDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var sortingMenuExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.PlayCircle,
                            contentDescription = "Tammu Logo",
                            tint = CyberCyan,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Tammu Player",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToStream) {
                        Icon(Icons.Default.Cloud, contentDescription = "Network Stream", tint = Color.White)
                    }
                    IconButton(onClick = onNavigateToVault) {
                        Icon(Icons.Default.Lock, contentDescription = "Private Vault", tint = CyberCyan)
                    }
                    IconButton(onClick = onNavigateToAds) {
                        Icon(Icons.Default.WorkspacePremium, contentDescription = "Ads and Premium", tint = Color.Yellow)
                    }
                    IconButton(onClick = {
                        viewModel.scanMedia()
                        Toast.makeText(context, "Scanning local storage...", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Scan Media", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            // Persistent Mini-Player overlay if active music/video is present
            if (currentMedia != null) {
                MiniPlayer(
                    item = currentMedia!!,
                    isPlaying = isPlaying,
                    onPlayPause = {
                        if (isPlaying) viewModel.pausePlayback() else viewModel.resumePlayback()
                    },
                    onNext = { viewModel.skipToNext() },
                    onClick = {
                        if (currentMedia!!.isVideo) {
                            onNavigateToVideo(currentMedia!!)
                        } else {
                            onNavigateToMusic(currentMedia!!)
                        }
                    }
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Input field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("Search videos, music, folders...", color = MutedText) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = MutedText) },
                trailingIcon = {
                    IconButton(onClick = { sortingMenuExpanded = true }) {
                        Icon(Icons.Default.Sort, contentDescription = "Sort Options", tint = CyberCyan)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .testTag("search_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = CarbonBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            // Sorting Dropdown Menu
            Box(modifier = Modifier.fillMaxWidth().wrapContentSize(Alignment.TopEnd)) {
                DropdownMenu(
                    expanded = sortingMenuExpanded,
                    onDismissRequest = { sortingMenuExpanded = false },
                    modifier = Modifier.background(CarbonSurfaceElevated)
                ) {
                    DropdownMenuItem(
                        text = { Text("Sort by Name", color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.SortByAlpha, contentDescription = null, tint = CyberCyan) },
                        onClick = {
                            viewModel.updateSortOption(SortOption.NAME)
                            sortingMenuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Sort by Size", color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.SdStorage, contentDescription = null, tint = CyberCyan) },
                        onClick = {
                            viewModel.updateSortOption(SortOption.SIZE)
                            sortingMenuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Sort by Date Added", color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, tint = CyberCyan) },
                        onClick = {
                            viewModel.updateSortOption(SortOption.DATE)
                            sortingMenuExpanded = false
                        }
                    )
                }
            }

            // High-fidelity Hero Branding banner (combining the generated image)
            HeroBrandingBanner()

            Spacer(modifier = Modifier.height(16.dp))

            // Scrollable Tab navigation
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 0.dp,
                containerColor = Color.Transparent,
                contentColor = CyberCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = CyberCyan
                    )
                },
                divider = {}
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 15.sp,
                                color = if (selectedTab == index) CyberCyan else MutedText
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tab View contents
            when (selectedTab) {
                0 -> VideosGrid(videosList, onNavigateToVideo, viewModel)
                1 -> MusicList(musicList, onNavigateToMusic, viewModel)
                2 -> FoldersList(videosList, musicList, onNavigateToVideo, onNavigateToMusic)
                3 -> PlaylistsTab(
                    playlists = playlistsList,
                    onCreatePlaylist = { showPlaylistDialog = true },
                    onDeletePlaylist = { viewModel.deletePlaylist(it) },
                    onPlayMedia = { item ->
                        if (item.isVideo) onNavigateToVideo(item) else onNavigateToMusic(item)
                    },
                    viewModel = viewModel
                )
            }
        }

        // Playlist Creation Dialog
        if (showPlaylistDialog) {
            AlertDialog(
                onDismissRequest = { showPlaylistDialog = false },
                title = { Text("Create Playlist", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = newPlaylistName,
                        onValueChange = { newPlaylistName = it },
                        placeholder = { Text("Enter playlist name", color = MutedText) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = Color.Gray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("playlist_name_input")
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newPlaylistName.isNotBlank()) {
                                viewModel.createPlaylist(newPlaylistName)
                                newPlaylistName = ""
                                showPlaylistDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                        modifier = Modifier.testTag("confirm_create_playlist")
                    ) {
                        Text("Create")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showPlaylistDialog = false }) {
                        Text("Cancel", color = MutedText)
                    }
                },
                containerColor = CarbonSurface
            )
        }
    }
}

@Composable
fun HeroBrandingBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(CarbonSurface, Color(0xFF151D2A))
                )
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_app_logo_1784387435832),
                contentDescription = "Tammu Player Brand Visual",
                modifier = Modifier
                    .size(88.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = "Ultimate Media Hub",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "High-fidelity audio equalizer, gestures, subtitle playback & private file locker.",
                    fontSize = 12.sp,
                    color = MutedText,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VideosGrid(videos: List<MediaItem>, onNavigate: (MediaItem) -> Unit, viewModel: MediaViewModel) {
    val context = LocalContext.current
    if (videos.isEmpty()) {
        EmptyStateView(icon = Icons.Default.VideoLibrary, message = "No videos found. Pull refresh or add video streams!")
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize().padding(bottom = 60.dp)
        ) {
            items(videos) { item ->
                var menuExpanded by remember { mutableStateOf(false) }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = { onNavigate(item) },
                            onLongClick = { menuExpanded = true }
                        ),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CarbonSurface)
                ) {
                    Box(modifier = Modifier.fillMaxWidth().height(100.dp)) {
                        // Custom video poster gradient container simulating thumbnails
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color(0xFF2A2A38), CarbonSurface)
                                    )
                                )
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = CyberCyan.copy(alpha = 0.6f),
                                modifier = Modifier
                                    .size(36.dp)
                                    .align(Alignment.Center)
                            )
                        }

                        // Floating duration tag
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(6.dp)
                                .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = item.durationFormatted,
                                color = Color.White,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = item.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = Color.White
                        )
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = item.sizeFormatted,
                                fontSize = 11.sp,
                                color = MutedText
                            )
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Menu",
                                tint = MutedText,
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable { menuExpanded = true }
                            )
                        }
                    }

                    // Dropdown Action Menu
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                        modifier = Modifier.background(CarbonSurfaceElevated)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Favorite", color = Color.White) },
                            leadingIcon = { Icon(Icons.Default.Favorite, null, tint = Color.Red) },
                            onClick = {
                                viewModel.toggleFavorite(item)
                                menuExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Hide to Vault", color = Color.White) },
                            leadingIcon = { Icon(Icons.Default.VisibilityOff, null, tint = CyberCyan) },
                            onClick = {
                                viewModel.hideMediaItem(item)
                                Toast.makeText(context, "Moved to private folder", Toast.LENGTH_SHORT).show()
                                menuExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Share", color = Color.White) },
                            leadingIcon = { Icon(Icons.Default.Share, null, tint = Color.White) },
                            onClick = {
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "Streaming video: ${item.title} at ${item.path}")
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, null))
                                menuExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete", color = Color.White) },
                            leadingIcon = { Icon(Icons.Default.Delete, null, tint = Color.Red) },
                            onClick = {
                                viewModel.deleteMediaFile(item)
                                menuExpanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MusicList(music: List<MediaItem>, onNavigate: (MediaItem) -> Unit, viewModel: MediaViewModel) {
    val context = LocalContext.current
    val playlists by viewModel.playlists.collectAsState()

    var showAddToPlaylistDialog by remember { mutableStateOf(false) }
    var selectedItemForPlaylist by remember { mutableStateOf<MediaItem?>(null) }

    if (music.isEmpty()) {
        EmptyStateView(icon = Icons.Default.MusicNote, message = "No audio tracks found. Stream some music files!")
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize().padding(bottom = 60.dp)
        ) {
            items(music) { item ->
                var menuExpanded by remember { mutableStateOf(false) }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(CarbonSurface)
                        .combinedClickable(
                            onClick = { onNavigate(item) },
                            onLongClick = { menuExpanded = true }
                        )
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF232330)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${item.artist} • ${item.album}",
                            fontSize = 11.sp,
                            color = MutedText,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Text(
                        text = item.durationFormatted,
                        fontSize = 12.sp,
                        color = MutedText,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = MutedText)
                    }
                }

                // Music dropdown actions
                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(CarbonSurfaceElevated)
                ) {
                    DropdownMenuItem(
                        text = { Text("Favorite", color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.Favorite, null, tint = Color.Red) },
                        onClick = {
                            viewModel.toggleFavorite(item)
                            menuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Add to Playlist", color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.PlaylistAdd, null, tint = CyberCyan) },
                        onClick = {
                            selectedItemForPlaylist = item
                            showAddToPlaylistDialog = true
                            menuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Hide to Vault", color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.VisibilityOff, null, tint = CyberCyan) },
                        onClick = {
                            viewModel.hideMediaItem(item)
                            Toast.makeText(context, "Added to Vault", Toast.LENGTH_SHORT).show()
                            menuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Share Track", color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.Share, null, tint = Color.White) },
                        onClick = {
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, "Play audio: ${item.title} by ${item.artist} via ${item.path}")
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, null))
                            menuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.Delete, null, tint = Color.Red) },
                        onClick = {
                            viewModel.deleteMediaFile(item)
                            menuExpanded = false
                        }
                    )
                }
            }
        }

        if (showAddToPlaylistDialog && selectedItemForPlaylist != null) {
            AlertDialog(
                onDismissRequest = { showAddToPlaylistDialog = false },
                title = { Text("Select Playlist", color = Color.White) },
                text = {
                    if (playlists.isEmpty()) {
                        Text("No playlists. Create one in the Playlists tab first!", color = MutedText)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(playlists) { playlist ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.addMediaToPlaylist(playlist.id, selectedItemForPlaylist!!)
                                            Toast.makeText(context, "Added to ${playlist.name}", Toast.LENGTH_SHORT).show()
                                            showAddToPlaylistDialog = false
                                        },
                                    colors = CardDefaults.cardColors(containerColor = CarbonSurfaceElevated)
                                ) {
                                    Text(
                                        text = playlist.name,
                                        color = Color.White,
                                        modifier = Modifier.padding(16.dp),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showAddToPlaylistDialog = false }) {
                        Text("Close", color = CyberCyan)
                    }
                },
                containerColor = CarbonSurface
            )
        }
    }
}

@Composable
fun FoldersList(
    videos: List<MediaItem>,
    music: List<MediaItem>,
    onPlayVideo: (MediaItem) -> Unit,
    onPlayMusic: (MediaItem) -> Unit
) {
    val allItems = videos + music
    val folders = allItems.groupBy { it.folderName }

    if (folders.isEmpty()) {
        EmptyStateView(icon = Icons.Default.Folder, message = "No folder structure detected.")
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize().padding(bottom = 60.dp)
        ) {
            folders.forEach { (folderName, itemsInFolder) ->
                item {
                    var expanded by remember { mutableStateOf(false) }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { expanded = !expanded }
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(32.dp))
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = folderName.ifEmpty { "Other Media" }, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text(text = "${itemsInFolder.size} files", fontSize = 12.sp, color = MutedText)
                                }
                                Icon(
                                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = MutedText
                                )
                            }

                            if (expanded) {
                                Divider(color = CarbonBorder)
                                Column(modifier = Modifier.padding(8.dp)) {
                                    itemsInFolder.forEach { mediaItem ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    if (mediaItem.isVideo) onPlayVideo(mediaItem) else onPlayMusic(mediaItem)
                                                }
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = if (mediaItem.isVideo) Icons.Default.PlayCircle else Icons.Default.MusicNote,
                                                contentDescription = null,
                                                tint = CyberCyan.copy(alpha = 0.8f),
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(
                                                text = mediaItem.title,
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Text(
                                                text = mediaItem.durationFormatted,
                                                fontSize = 11.sp,
                                                color = MutedText
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistsTab(
    playlists: List<PlaylistEntity>,
    onCreatePlaylist: () -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onPlayMedia: (MediaItem) -> Unit,
    viewModel: MediaViewModel
) {
    Column(modifier = Modifier.fillMaxSize().padding(bottom = 60.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Your Playlists", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            Button(
                onClick = onCreatePlaylist,
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("create_playlist_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("New")
            }
        }

        if (playlists.isEmpty()) {
            EmptyStateView(icon = Icons.Default.PlaylistPlay, message = "Create custom playlists to organize your favorite content!")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(playlists) { playlist ->
                    var isExpanded by remember { mutableStateOf(false) }
                    val playlistItemsFlow = remember(playlist.id) { viewModel.getPlaylistItems(playlist.id) }
                    val playlistItems by playlistItemsFlow.collectAsState()

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CarbonSurface)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isExpanded = !isExpanded }
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFF262635), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.PlaylistPlay, null, tint = CyberCyan)
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(playlist.name, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text("${playlistItems.size} tracks", fontSize = 12.sp, color = MutedText)
                                }
                                IconButton(onClick = { onDeletePlaylist(playlist.id) }) {
                                    Icon(Icons.Default.DeleteOutline, "Delete Playlist", tint = Color.Red)
                                }
                                Icon(
                                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = MutedText
                                )
                            }

                            if (isExpanded) {
                                Divider(color = CarbonBorder)
                                if (playlistItems.isEmpty()) {
                                    Text(
                                        "Playlist is empty. Add tracks from the Music tab!",
                                        fontSize = 12.sp,
                                        color = MutedText,
                                        modifier = Modifier.padding(16.dp)
                                    )
                                } else {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        playlistItems.forEach { pItem ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        onPlayMedia(
                                                            MediaItem(
                                                                title = pItem.title,
                                                                path = pItem.mediaPath,
                                                                isVideo = pItem.isVideo
                                                            )
                                                        )
                                                    }
                                                    .padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = if (pItem.isVideo) Icons.Default.PlayCircle else Icons.Default.MusicNote,
                                                    contentDescription = null,
                                                    tint = CyberCyan,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Text(
                                                    text = pItem.title,
                                                    color = Color.White,
                                                    fontSize = 13.sp,
                                                    modifier = Modifier.weight(1f),
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                IconButton(
                                                    onClick = {
                                                        viewModel.removeMediaFromPlaylist(playlist.id, pItem.mediaPath)
                                                    },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Default.Close, "Remove item", tint = Color.Red, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(
    item: MediaItem,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(CarbonSurfaceElevated)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF262635)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (item.isVideo) Icons.Default.PlayCircle else Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (item.isVideo) "Video Player" else item.artist,
                    fontSize = 11.sp,
                    color = MutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(onClick = onPlayPause) {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "PlayPause",
                    tint = CyberCyan,
                    modifier = Modifier.size(28.dp)
                )
            }

            IconButton(onClick = onNext) {
                Icon(
                    imageVector = Icons.Filled.SkipNext,
                    contentDescription = "Next",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}

@Composable
fun EmptyStateView(icon: ImageVector, message: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MutedText.copy(alpha = 0.4f),
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = message,
            color = MutedText,
            fontSize = 14.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally),
            fontWeight = FontWeight.Medium
        )
    }
}
