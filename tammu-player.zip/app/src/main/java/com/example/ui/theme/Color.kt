package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Luxury Cinematic Theme Colors
val CarbonBg = Color(0xFF08080B)
val CarbonSurface = Color(0xFF121217)
val CarbonSurfaceElevated = Color(0xFF1C1C24)
val CyberCyan = Color(0xFF00FFD1)
val CyberBlue = Color(0xFF0091FF)
val BrightOrange = Color(0xFFFF6D00)
val MutedText = Color(0xFF8F8F9F)
val CarbonBorder = Color(0xFF22222E)
val LightSurface = Color(0xFFF5F5FA)
val LightBg = Color(0xFFFAFAFF)

