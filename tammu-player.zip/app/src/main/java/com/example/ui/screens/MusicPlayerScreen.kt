package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaItem
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceElevated
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MutedText
import com.example.ui.viewmodel.MediaViewModel
import kotlinx.coroutines.launch

@Composable
fun MusicPlayerScreen(
    viewModel: MediaViewModel,
    mediaItem: MediaItem,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    val currentMedia by viewModel.currentMediaItem.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val duration by viewModel.duration.collectAsState()
    val shuffleMode by viewModel.shuffleMode.collectAsState()
    val sleepMinutesLeft by viewModel.sleepMinutesLeft.collectAsState()

    // Equalizer States
    val eqBands by viewModel.equalizerBands.collectAsState()
    val bassBoost by viewModel.bassBoost.collectAsState()
    val audioBoost by viewModel.audioBoost.collectAsState()

    var showEqualizerSheet by remember { mutableStateOf(false) }
    var showSleepTimerSheet by remember { mutableStateOf(false) }

    // Infinite rotation for vinyl disc when playing
    val infiniteTransition = rememberInfiniteTransition(label = "VinylDisc")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Rotation"
    )
    val vinylRotation = if (isPlaying) rotationAngle else 0f

    // Play initial music if needed
    LaunchedEffect(mediaItem.path) {
        if (viewModel.currentMediaItem.value?.path != mediaItem.path) {
            viewModel.playMedia(mediaItem)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F1424), Color(0xFF070709))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "NOW PLAYING",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 14.sp,
                    letterSpacing = 2.sp
                )
                IconButton(onClick = { viewModel.toggleFavorite(mediaItem) }) {
                    Icon(Icons.Default.Favorite, contentDescription = "Favorite", tint = Color.Red)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Beautiful rotating vinyl disk simulation
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .clip(CircleShape)
                    .background(Color.Black)
                    .rotate(vinylRotation)
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                // Vinyl outer ridges
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                colors = listOf(Color(0xFF1E1E1E), Color(0xFF080808), Color(0xFF1E1E1E))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    // Center Disc label art representation
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(CyberCyan, Color(0xFF003050))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Metadata info titles
            Text(
                text = mediaItem.title,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color.White,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${mediaItem.artist} • ${mediaItem.album}",
                fontSize = 14.sp,
                color = MutedText,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )

            // Animated wave indicator
            Spacer(modifier = Modifier.height(16.dp))
            BounceBarsVisualizer(isActive = isPlaying)

            Spacer(modifier = Modifier.weight(1f))

            // Sliders Progress Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatTime(progress),
                    color = MutedText,
                    fontSize = 12.sp
                )
                Slider(
                    value = progress.toFloat(),
                    onValueChange = { viewModel.seekTo(it.toLong()) },
                    valueRange = 0f..(duration.toFloat().coerceAtLeast(1f)),
                    colors = SliderDefaults.colors(
                        thumbColor = CyberCyan,
                        activeTrackColor = CyberCyan,
                        inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp)
                        .testTag("music_progress_slider")
                )
                Text(
                    text = formatTime(duration),
                    color = MutedText,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Media controls bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.toggleShuffle() }) {
                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (shuffleMode) CyberCyan else MutedText
                    )
                }

                IconButton(onClick = { viewModel.skipToPrevious() }) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "Previous",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                IconButton(
                    onClick = {
                        if (isPlaying) viewModel.pausePlayback() else viewModel.resumePlayback()
                    },
                    modifier = Modifier
                        .size(68.dp)
                        .background(CyberCyan, CircleShape)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "PlayPause",
                        tint = Color.Black,
                        modifier = Modifier.size(36.dp)
                    )
                }

                IconButton(onClick = { viewModel.skipToNext() }) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Next",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                IconButton(onClick = { viewModel.toggleRepeat() }) {
                    Icon(
                        imageVector = Icons.Default.Repeat,
                        contentDescription = "Repeat",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Secondary Equalizer and Sleep Timer tools
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = { showEqualizerSheet = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CarbonSurface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.GraphicEq, contentDescription = null, tint = CyberCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Equalizer", color = Color.White)
                }

                Button(
                    onClick = { showSleepTimerSheet = true },
                    colors = ButtonDefaults.buttonColors(containerColor = CarbonSurface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = CyberCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (sleepMinutesLeft > 0) "${sleepMinutesLeft}m left" else "Sleep Timer",
                        color = Color.White
                    )
                }
            }
        }

        // Equalizer Sliders panel Sheet overlay
        if (showEqualizerSheet) {
            AlertDialog(
                onDismissRequest = { showEqualizerSheet = false },
                title = { Text("Tammu Audio Equalizer", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Preset chips row
                        Text("Sound Presets", color = MutedText, fontSize = 12.sp)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            val presets = listOf("Flat", "Rock", "Pop", "Jazz")
                            presets.forEach { preset ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CarbonSurfaceElevated)
                                        .clickable {
                                            // Emulate loading preset values
                                            val presetVals = when (preset) {
                                                "Rock" -> listOf(75f, 65f, 40f, 60f, 75f)
                                                "Pop" -> listOf(40f, 55f, 70f, 60f, 40f)
                                                "Jazz" -> listOf(65f, 50f, 45f, 55f, 65f)
                                                else -> listOf(50f, 50f, 50f, 50f, 50f)
                                            }
                                            presetVals.forEachIndexed { idx, valPercent ->
                                                viewModel.updateEqualizerBand(idx, valPercent)
                                            }
                                            Toast.makeText(context, "Applied $preset preset", Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(preset, color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }

                        Divider(color = Color.Gray.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                        // 5 Bands Equalizer
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val frequencies = listOf("60Hz", "230Hz", "910Hz", "4kHz", "14kHz")
                            eqBands.forEachIndexed { index, bandValue ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Slider(
                                        value = bandValue,
                                        onValueChange = { viewModel.updateEqualizerBand(index, it) },
                                        valueRange = 0f..100f,
                                        colors = SliderDefaults.colors(
                                            thumbColor = CyberCyan,
                                            activeTrackColor = CyberCyan
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .width(200.dp)
                                            // Simple custom simulation of vertical layouts in compose using rotate
                                            .rotate(-90f)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(frequencies[index], color = Color.White, fontSize = 10.sp)
                                }
                            }
                        }

                        Divider(color = Color.Gray.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 8.dp))

                        // Bass Boost and Audio Enhancers Sliders
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Bass Boost", color = Color.White, fontSize = 12.sp)
                                Slider(
                                    value = bassBoost,
                                    onValueChange = { viewModel.updateBassBoost(it) },
                                    valueRange = 0f..100f,
                                    colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Loudness Boost", color = Color.White, fontSize = 12.sp)
                                Slider(
                                    value = audioBoost,
                                    onValueChange = { viewModel.updateAudioBoost(it) },
                                    valueRange = 0f..100f,
                                    colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showEqualizerSheet = false }) {
                        Text("Apply", color = CyberCyan)
                    }
                },
                containerColor = CarbonSurface
            )
        }

        // Sleep Timer Selection panel dialog
        if (showSleepTimerSheet) {
            AlertDialog(
                onDismissRequest = { showSleepTimerSheet = false },
                title = { Text("Set Sleep Timer", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        val timerMinutes = listOf(5, 15, 30, 45, 60)
                        timerMinutes.forEach { min ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.startSleepTimer(min)
                                        Toast.makeText(context, "Timer armed for $min mins", Toast.LENGTH_SHORT).show()
                                        showSleepTimerSheet = false
                                    }
                                    .padding(vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("$min Minutes", color = Color.White)
                                if (sleepMinutesLeft == min) {
                                    Icon(Icons.Default.Check, null, tint = CyberCyan)
                                }
                            }
                        }

                        if (sleepMinutesLeft > 0) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.cancelSleepTimer()
                                        Toast.makeText(context, "Timer cancelled", Toast.LENGTH_SHORT).show()
                                        showSleepTimerSheet = false
                                    }
                                    .padding(vertical = 12.dp)
                            ) {
                                Text("Turn Off Timer", color = Color.Red, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                confirmButton = {},
                containerColor = CarbonSurface
            )
        }
    }
}

@Composable
fun BounceBarsVisualizer(isActive: Boolean) {
    Row(
        modifier = Modifier
            .height(24.dp)
            .width(60.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        val barHeights = listOf(0.4f, 0.9f, 0.6f, 0.8f, 0.5f)
        barHeights.forEachIndexed { idx, targetHeight ->
            val heightMultiplier by animateFloatAsState(
                targetValue = if (isActive) ((20..100).random() / 100f) else 0.15f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = (200..400).random(), easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "visualizer_bar_$idx"
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(heightMultiplier)
                    .clip(RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp))
                    .background(CyberCyan)
            )
        }
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "00:00"
    val seconds = (ms / 1000) % 60
    val minutes = (ms / (1000 * 60)) % 60
    return String.format("%02d:%02d", minutes, seconds)
}
