package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.database.AppDatabase
import com.example.data.database.FavoriteEntity
import com.example.data.database.PlaylistEntity
import com.example.data.database.PlaylistItemEntity
import com.example.data.database.PrivateMediaEntity
import com.example.data.database.MediaRepository
import com.example.data.model.MediaItem
import com.example.data.provider.MediaScanner
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SortOption { NAME, SIZE, DATE }

class MediaViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = MediaRepository(database.mediaDao())

    // Master list of all media items loaded/scanned
    private val _rawMediaList = MutableStateFlow<List<MediaItem>>(emptyList())
    val rawMediaList: StateFlow<List<MediaItem>> = _rawMediaList.asStateFlow()

    // Search and Sort states
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _sortOption = MutableStateFlow(SortOption.NAME)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    // Playlists & Favorites from Room Database
    val favorites: StateFlow<List<FavoriteEntity>> = repository.favorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val playlists: StateFlow<List<PlaylistEntity>> = repository.playlists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyPlayedFlow = repository.recentlyPlayed
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val privateMedia: StateFlow<List<PrivateMediaEntity>> = repository.privateMedia
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Vault Authentication States
    private val _vaultUnlocked = MutableStateFlow(false)
    val vaultUnlocked: StateFlow<Boolean> = _vaultUnlocked.asStateFlow()

    private val _vaultHasPin = MutableStateFlow(false)
    val vaultHasPin: StateFlow<Boolean> = _vaultHasPin.asStateFlow()

    // Filtered Video and Music lists based on search/sort
    val videos: StateFlow<List<MediaItem>> = combine(_rawMediaList, _searchQuery, _sortOption, repository.privateMedia) { list, query, sort, hidden ->
        val hiddenPaths = hidden.map { it.mediaPath }.toSet()
        val filtered = list.filter { it.isVideo && !hiddenPaths.contains(it.path) }
            .filter { it.title.contains(query, ignoreCase = true) }
        
        sortList(filtered, sort)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val music: StateFlow<List<MediaItem>> = combine(_rawMediaList, _searchQuery, _sortOption, repository.privateMedia) { list, query, sort, hidden ->
        val hiddenPaths = hidden.map { it.mediaPath }.toSet()
        val filtered = list.filter { !it.isVideo && !hiddenPaths.contains(it.path) }
            .filter { it.title.contains(query, ignoreCase = true) || it.artist.contains(query, ignoreCase = true) }
        
        sortList(filtered, sort)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Single central ExoPlayer instance
    private var exoPlayer: ExoPlayer? = null
    
    private val _currentMediaItem = MutableStateFlow<MediaItem?>(null)
    val currentMediaItem: StateFlow<MediaItem?> = _currentMediaItem.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _progress = MutableStateFlow(0L)
    val progress: StateFlow<Long> = _progress.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _shuffleMode = MutableStateFlow(false)
    val shuffleMode: StateFlow<Boolean> = _shuffleMode.asStateFlow()

    private val _repeatMode = MutableStateFlow(false) // false -> Off/All, true -> Repeat One

    // Active playlist/playing queue
    private var playingQueue = listOf<MediaItem>()
    private var currentIndexInQueue = -1

    // Sound Enhancements & Equalizer Simulation State
    private val _audioBoost = MutableStateFlow(0f) // 0 to 100
    val audioBoost: StateFlow<Float> = _audioBoost.asStateFlow()

    private val _bassBoost = MutableStateFlow(0f) // 0 to 100
    val bassBoost: StateFlow<Float> = _bassBoost.asStateFlow()

    private val _equalizerBands = MutableStateFlow(listOf(50f, 50f, 50f, 50f, 50f)) // 5 bands at 50% default
    val equalizerBands: StateFlow<List<Float>> = _equalizerBands.asStateFlow()

    // Sleep Timer state
    private val _sleepMinutesLeft = MutableStateFlow(0)
    val sleepMinutesLeft: StateFlow<Int> = _sleepMinutesLeft.asStateFlow()
    private var sleepTimerJob: Job? = null

    init {
        // Run initial scan
        scanMedia()
        checkVaultStatus()
        
        // Initialize ExoPlayer
        viewModelScope.launch {
            exoPlayer = ExoPlayer.Builder(application).build().apply {
                playWhenReady = false
                
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        if (state == Player.STATE_READY) {
                            _duration.value = duration
                            // Save recently played / progress resume
                            _currentMediaItem.value?.let { current ->
                                viewModelScope.launch {
                                    repository.insertRecentlyPlayed(
                                        path = current.path,
                                        title = current.title,
                                        duration = duration,
                                        progress = currentPosition,
                                        isVideo = current.isVideo
                                    )
                                }
                            }
                        } else if (state == Player.STATE_ENDED) {
                            handleMediaEnded()
                        }
                    }

                    override fun onIsPlayingChanged(isPlayingChange: Boolean) {
                        _isPlaying.value = isPlayingChange
                    }
                })
            }

            // Progress tracking loop
            while (true) {
                delay(1000)
                exoPlayer?.let { player ->
                    if (player.isPlaying) {
                        _progress.value = player.currentPosition
                        // Periodically update progress resume
                        _currentMediaItem.value?.let { current ->
                            repository.insertRecentlyPlayed(
                                path = current.path,
                                title = current.title,
                                duration = player.duration,
                                progress = player.currentPosition,
                                isVideo = current.isVideo
                            )
                        }
                    }
                }
            }
        }
    }

    fun scanMedia() {
        viewModelScope.launch {
            val list = MediaScanner.scanMedia(getApplication())
            _rawMediaList.value = list
        }
    }

    private fun sortList(list: List<MediaItem>, sort: SortOption): List<MediaItem> {
        return when (sort) {
            SortOption.NAME -> list.sortedBy { it.title }
            SortOption.SIZE -> list.sortedByDescending { it.size }
            SortOption.DATE -> list.sortedByDescending { it.dateAdded }
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateSortOption(option: SortOption) {
        _sortOption.value = option
    }

    // --- Equalizer & Enhancers Simulation ---
    fun updateAudioBoost(level: Float) {
        _audioBoost.value = level
        // Realistic audio level multiplier emulation inside player
        exoPlayer?.volume = 1.0f + (level / 100f) // Audio boost emulation
    }

    fun updateBassBoost(level: Float) {
        _bassBoost.value = level
    }

    fun updateEqualizerBand(index: Int, value: Float) {
        val current = _equalizerBands.value.toMutableList()
        if (index in current.indices) {
            current[index] = value
            _equalizerBands.value = current
        }
    }

    // --- Sleep Timer ---
    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepMinutesLeft.value = minutes
        if (minutes > 0) {
            sleepTimerJob = viewModelScope.launch {
                while (_sleepMinutesLeft.value > 0) {
                    delay(60000) // wait 1 minute
                    _sleepMinutesLeft.value -= 1
                }
                pausePlayback()
            }
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepMinutesLeft.value = 0
    }

    // --- Playback Controls ---
    fun getExoPlayer(): ExoPlayer? = exoPlayer

    fun playMedia(item: MediaItem, queue: List<MediaItem> = emptyList()) {
        viewModelScope.launch {
            _currentMediaItem.value = item
            playingQueue = queue.ifEmpty { listOf(item) }
            currentIndexInQueue = playingQueue.indexOfFirst { it.path == item.path }
            
            exoPlayer?.let { player ->
                player.stop()
                player.clearMediaItems()
                val exoMediaItem = ExoMediaItem.fromUri(item.path)
                player.setMediaItem(exoMediaItem)
                
                // Resume position support
                val history = repository.recentlyPlayed.stateIn(viewModelScope).value
                val matchedHistory = history.find { it.mediaPath == item.path }
                if (matchedHistory != null && matchedHistory.lastProgress > 5000 && matchedHistory.lastProgress < matchedHistory.duration - 5000) {
                    player.seekTo(matchedHistory.lastProgress)
                }

                player.setPlaybackSpeed(_playbackSpeed.value)
                player.prepare()
                player.play()
            }
        }
    }

    fun pausePlayback() {
        exoPlayer?.pause()
    }

    fun resumePlayback() {
        exoPlayer?.play()
    }

    fun seekTo(positionMs: Long) {
        exoPlayer?.seekTo(positionMs)
        _progress.value = positionMs
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        exoPlayer?.setPlaybackSpeed(speed)
    }

    fun toggleShuffle() {
        _shuffleMode.value = !_shuffleMode.value
    }

    fun toggleRepeat() {
        _repeatMode.value = !_repeatMode.value
        exoPlayer?.repeatMode = if (_repeatMode.value) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    fun skipToNext() {
        if (playingQueue.isEmpty()) return
        
        if (_shuffleMode.value) {
            currentIndexInQueue = (playingQueue.indices).random()
        } else {
            currentIndexInQueue = (currentIndexInQueue + 1) % playingQueue.size
        }
        
        val nextItem = playingQueue.getOrNull(currentIndexInQueue)
        if (nextItem != null) {
            playMedia(nextItem, playingQueue)
        }
    }

    fun skipToPrevious() {
        if (playingQueue.isEmpty()) return
        currentIndexInQueue = if (currentIndexInQueue - 1 < 0) playingQueue.size - 1 else currentIndexInQueue - 1
        val prevItem = playingQueue.getOrNull(currentIndexInQueue)
        if (prevItem != null) {
            playMedia(prevItem, playingQueue)
        }
    }

    private fun handleMediaEnded() {
        if (playingQueue.size > 1) {
            skipToNext()
        } else {
            _isPlaying.value = false
            _progress.value = 0L
        }
    }

    // --- Favorites management ---
    fun toggleFavorite(item: MediaItem) {
        viewModelScope.launch {
            if (repository.isFavorite(item.path)) {
                repository.removeFavorite(item.path)
            } else {
                repository.addFavorite(item.path, item.title, item.isVideo)
            }
        }
    }

    // --- Playlists Management ---
    fun createPlaylist(name: String, description: String = "") {
        viewModelScope.launch {
            repository.createPlaylist(name, description)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
        }
    }

    fun addMediaToPlaylist(playlistId: Long, item: MediaItem) {
        viewModelScope.launch {
            repository.addPlaylistItem(playlistId, item.path, item.title, item.isVideo)
        }
    }

    fun removeMediaFromPlaylist(playlistId: Long, path: String) {
        viewModelScope.launch {
            repository.removePlaylistItem(playlistId, path)
        }
    }

    fun getPlaylistItems(playlistId: Long): StateFlow<List<PlaylistItemEntity>> {
        return repository.getPlaylistItems(playlistId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    // --- Private Vault lock folder management ---
    private fun checkVaultStatus() {
        viewModelScope.launch {
            val pin = repository.getVaultPin()
            _vaultHasPin.value = pin != null
        }
    }

    fun setupVaultPin(pin: String) {
        viewModelScope.launch {
            repository.setVaultPin(pin)
            _vaultHasPin.value = true
            _vaultUnlocked.value = true
        }
    }

    fun unlockVault(pin: String): Boolean {
        var success = false
        viewModelScope.launch {
            val saved = repository.getVaultPin()
            if (saved == pin) {
                _vaultUnlocked.value = true
                success = true
            }
        }
        return success
    }

    fun lockVault() {
        _vaultUnlocked.value = false
    }

    fun hideMediaItem(item: MediaItem) {
        viewModelScope.launch {
            // Register file path as locked in DB
            repository.addPrivateMedia(
                path = item.path,
                originalPath = item.path,
                title = item.title,
                isVideo = item.isVideo
            )
            // If playing the currently hidden media, pause and clear
            if (_currentMediaItem.value?.path == item.path) {
                exoPlayer?.stop()
                _currentMediaItem.value = null
            }
        }
    }

    fun restoreMediaItem(hidden: PrivateMediaEntity) {
        viewModelScope.launch {
            repository.removePrivateMedia(hidden.mediaPath)
        }
    }

    // --- File operations (Mock + actual file helper calls) ---
    fun renameMediaFile(item: MediaItem, newName: String) {
        // Find in master raw list, update local list
        val updated = _rawMediaList.value.map {
            if (it.path == item.path) it.copy(title = newName) else it
        }
        _rawMediaList.value = updated
    }

    fun deleteMediaFile(item: MediaItem) {
        // Remove from raw lists
        val updated = _rawMediaList.value.filter { it.path != item.path }
        _rawMediaList.value = updated
        
        // Clear from favorites and history
        viewModelScope.launch {
            repository.deleteRecentlyPlayed(item.path)
            repository.removeFavorite(item.path)
        }
    }

    override fun onCleared() {
        super.onCleared()
        exoPlayer?.release()
        exoPlayer = null
        sleepTimerJob?.cancel()
    }
}
