package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceElevated
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MutedText
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AdsShowcaseScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var showInterstitialAd by remember { mutableStateOf(false) }
    var interstitialCountdown by remember { mutableStateOf(5) }

    var showRewardedAd by remember { mutableStateOf(false) }
    var rewardedCountdown by remember { mutableStateOf(10) }
    var rewardedProgress by remember { mutableStateOf(0f) }

    var userPremiumDurationHours by remember { mutableStateOf(0) }

    // Interstitial timer
    LaunchedEffect(showInterstitialAd) {
        if (showInterstitialAd) {
            interstitialCountdown = 5
            while (interstitialCountdown > 0) {
                delay(1000)
                interstitialCountdown -= 1
            }
        }
    }

    // Rewarded progress bar and timer
    LaunchedEffect(showRewardedAd) {
        if (showRewardedAd) {
            rewardedCountdown = 10
            rewardedProgress = 0f
            while (rewardedCountdown > 0) {
                delay(1000)
                rewardedCountdown -= 1
                rewardedProgress = (10f - rewardedCountdown) / 10f
            }
            userPremiumDurationHours += 1
            showRewardedAd = false
            Toast.makeText(context, "Congratulations! You have been granted 1 Hour of Premium!", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "AdMob Monetization & Premium",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
            ) {
                // Premium Card Status
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFFFF8F00), Color(0xFFFF3D00))
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Tammu Premium Gold",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (userPremiumDurationHours > 0) {
                                "PREMIUM ACTIVE • Expires in $userPremiumDurationHours Hour(s)!"
                            } else {
                                "Experience ad-free 4K playback, premium sound enhancements, and unlocked private folders."
                            },
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Simulate Ad Placements",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Experience standard AdMob formats utilized inside Tammu Player's codebase.",
                    fontSize = 12.sp,
                    color = MutedText
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Interstitial Ad trigger button
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showInterstitialAd = true },
                    colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFF262635), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Fullscreen, null, tint = CyberCyan)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Play Interstitial Ad", fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Full-screen immersive commercial layout.", fontSize = 12.sp, color = MutedText)
                        }
                        Icon(Icons.Default.PlayArrow, null, tint = CyberCyan)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Rewarded Ad trigger button
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showRewardedAd = true },
                    colors = CardDefaults.cardColors(containerColor = CarbonSurface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFF262635), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.FeaturedVideo, null, tint = CyberCyan)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Watch Rewarded Video Ad", fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Earn 1 hour of ad-free Premium on complete.", fontSize = 12.sp, color = MutedText)
                        }
                        Icon(Icons.Default.CardGiftcard, null, tint = Color.Yellow)
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // AdMob Banner Ad placement (Always visible at the bottom)
                BannerAdView()
            }

            // --- Interstitial Ad Full Screen Overlay ---
            AnimatedVisibility(
                visible = showInterstitialAd,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(Color.DarkGray, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("Ad • Google AdMob", color = Color.White, fontSize = 10.sp)
                            }

                            if (interstitialCountdown > 0) {
                                Text(
                                    text = "Close in $interstitialCountdown...",
                                    color = Color.White,
                                    fontSize = 12.sp
                                )
                            } else {
                                IconButton(
                                    onClick = { showInterstitialAd = false },
                                    modifier = Modifier.background(Color.White.copy(alpha = 0.2f), CircleShape)
                                ) {
                                    Icon(Icons.Default.Close, "Close Ad", tint = Color.White)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(48.dp))

                        // Large Creative Banner
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(300.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color(0xFF6200EE), Color(0xFF3700B3))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.CloudUpload, null, tint = Color.White, modifier = Modifier.size(80.dp))
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "Tammu Cloud Sync",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 24.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Backup your entire playlists to the secure cloud.",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(32.dp))

                        Button(
                            onClick = {
                                Toast.makeText(context, "Sync trial initialized!", Toast.LENGTH_SHORT).show()
                                showInterstitialAd = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Text("Try Backup Free", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // --- Rewarded Ad Full Screen Overlay ---
            AnimatedVisibility(
                visible = showRewardedAd,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF07070F))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(Color.Red, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("VIDEO COMMERCIAL", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = "Reward in: $rewardedCountdown sec",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(48.dp))

                        // Large Simulated Video surface
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.Black)
                                .border(1.dp, CyberCyan, RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.MovieFilter, null, tint = CyberCyan, modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "Watch & Earn Rewards",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    val heights = listOf(0.4f, 0.8f, 0.5f, 0.9f, 0.3f)
                                    heights.forEach { h ->
                                        Box(
                                            modifier = Modifier
                                                .height(16.dp)
                                                .width(4.dp)
                                                .background(CyberCyan)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        LinearProgressIndicator(
                            progress = { rewardedProgress },
                            color = CyberCyan,
                            trackColor = Color.DarkGray,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape)
                        )

                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "Watching this ad supports independent developers. Do not close early!",
                            color = MutedText,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BannerAdView() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(CarbonSurfaceElevated)
            .border(1.dp, CyberCyan.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .background(CyberCyan, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text("Ad", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }

            Text(
                text = "Want ad-free playback? Try Premium!",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
            )

            Icon(
                imageVector = Icons.Default.Launch,
                contentDescription = null,
                tint = CyberCyan,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
