package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.database.PrivateMediaEntity
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CarbonSurfaceElevated
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MutedText
import com.example.ui.viewmodel.MediaViewModel

@Composable
fun VaultScreen(
    viewModel: MediaViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val hasPin by viewModel.vaultHasPin.collectAsState()
    val isUnlocked by viewModel.vaultUnlocked.collectAsState()
    val privateMediaList by viewModel.privateMedia.collectAsState()

    var enteredPin by remember { mutableStateOf("") }
    var pinSetupStep by remember { mutableStateOf(0) } // 0 -> enter new pin, 1 -> confirm new pin
    var tempSetupPin by remember { mutableStateOf("") }

    // Lock the vault whenever we leave this screen
    DisposableEffect(Unit) {
        onDispose {
            viewModel.lockVault()
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Private Media Vault",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.weight(1f))
                if (isUnlocked) {
                    IconButton(onClick = { viewModel.lockVault() }) {
                        Icon(Icons.Default.Lock, contentDescription = "Lock", tint = Color.Red)
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (!hasPin) {
                // PIN Setup Flow
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(72.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (pinSetupStep == 0) "Set Secure Lock PIN" else "Confirm Security PIN",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Protect your hidden videos and private music tracks with a 4-digit master PIN.",
                        fontSize = 13.sp,
                        color = MutedText,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    // PIN Dots
                    PinDotsRow(enteredPinLength = enteredPin.length)

                    Spacer(modifier = Modifier.height(32.dp))

                    // Custom Keyboard
                    KeyboardKeypad(
                        onDigitClick = { digit ->
                            if (enteredPin.length < 4) {
                                enteredPin += digit
                                if (enteredPin.length == 4) {
                                    if (pinSetupStep == 0) {
                                        tempSetupPin = enteredPin
                                        enteredPin = ""
                                        pinSetupStep = 1
                                    } else {
                                        if (enteredPin == tempSetupPin) {
                                            viewModel.setupVaultPin(enteredPin)
                                            Toast.makeText(context, "Private vault armed successfully!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, "PINs do not match. Try again!", Toast.LENGTH_SHORT).show()
                                            enteredPin = ""
                                            pinSetupStep = 0
                                        }
                                    }
                                }
                            }
                        },
                        onBackspaceClick = {
                            if (enteredPin.isNotEmpty()) {
                                enteredPin = enteredPin.dropLast(1)
                            }
                        }
                    )
                }
            } else if (!isUnlocked) {
                // PIN Entry Authentication Form
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(72.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Enter Vault Passcode",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Authentication required to access hidden media.",
                        fontSize = 13.sp,
                        color = MutedText
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    // PIN Dots
                    PinDotsRow(enteredPinLength = enteredPin.length)

                    Spacer(modifier = Modifier.height(32.dp))

                    // Keypad
                    KeyboardKeypad(
                        onDigitClick = { digit ->
                            if (enteredPin.length < 4) {
                                enteredPin += digit
                                if (enteredPin.length == 4) {
                                    val success = viewModel.unlockVault(enteredPin)
                                    if (!success) {
                                        // Wait a tiny fraction and notify error if incorrect
                                        Toast.makeText(context, "Incorrect PIN code!", Toast.LENGTH_SHORT).show()
                                        enteredPin = ""
                                    }
                                }
                            }
                        },
                        onBackspaceClick = {
                            if (enteredPin.isNotEmpty()) {
                                enteredPin = enteredPin.dropLast(1)
                            }
                        }
                    )
                }
            } else {
                // Authenticated & Unlocked Dashboard View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CarbonSurface)
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = CyberCyan)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Hidden items are safe from automatic scanners and general storage sweeps. Press the button to unhide.",
                            color = MutedText,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (privateMediaList.isEmpty()) {
                        Column(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.FolderZip, "Empty Vault", tint = MutedText.copy(alpha = 0.3f), modifier = Modifier.size(80.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Vault is empty.", color = MutedText, fontWeight = FontWeight.Medium)
                            Text("Long press any video or track to hide it here.", color = MutedText.copy(alpha = 0.7f), fontSize = 12.sp)
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(privateMediaList) { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(CarbonSurface)
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF262635)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (item.isVideo) Icons.Default.PlayCircle else Icons.Default.MusicNote,
                                            contentDescription = null,
                                            tint = CyberCyan
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.title,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = if (item.isVideo) "Hidden Video" else "Hidden Music Track",
                                            fontSize = 11.sp,
                                            color = MutedText
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.restoreMediaItem(item)
                                            Toast.makeText(context, "Restored back to Media Library", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Visibility, "Restore", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Unhide", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PinDotsRow(enteredPinLength: Int) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until 4) {
            val isFilled = i < enteredPinLength
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(
                        if (isFilled) CyberCyan else Color.White.copy(alpha = 0.2f)
                    )
            )
        }
    }
}

@Composable
fun KeyboardKeypad(
    onDigitClick: (String) -> Unit,
    onBackspaceClick: () -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(280.dp)
    ) {
        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("", "0", "delete")
        )

        rows.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                row.forEach { char ->
                    if (char.isEmpty()) {
                        Spacer(modifier = Modifier.size(64.dp))
                    } else if (char == "delete") {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(CarbonSurface)
                                .clickable { onBackspaceClick() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Backspace, contentDescription = "Delete", tint = Color.White)
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(CarbonSurface)
                                .clickable { onDigitClick(char) }
                                .testTag("keypad_btn_$char"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = char,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
