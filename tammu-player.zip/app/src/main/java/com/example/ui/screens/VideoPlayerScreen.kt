package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.provider.Settings
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import com.example.data.model.MediaItem
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MutedText
import com.example.ui.viewmodel.MediaViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun VideoPlayerScreen(
    viewModel: MediaViewModel,
    mediaItem: MediaItem,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val coroutineScope = rememberCoroutineScope()
    
    val exoPlayer = viewModel.getExoPlayer()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val duration by viewModel.duration.collectAsState()
    val playbackSpeed by viewModel.playbackSpeed.collectAsState()
    val audioBoost by viewModel.audioBoost.collectAsState()

    // Interface HUD state
    var showControls by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }

    // Volume & Brightness helper values
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    
    var currentVolume by remember {
        mutableStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC))
    }
    var currentBrightness by remember {
        mutableStateOf(
            activity?.window?.attributes?.screenBrightness ?: 0.5f
        )
    }

    // Overlay feedback indicators
    var gestureOverlayText by remember { mutableStateOf("") }
    var showGestureIndicator by remember { mutableStateOf(false) }

    var showSpeedDialog by remember { mutableStateOf(false) }
    var showAudioBoostDialog by remember { mutableStateOf(false) }

    // Auto-hide controls loop
    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            delay(5000)
            showControls = false
        }
    }

    // Trigger Playback if changed
    LaunchedEffect(mediaItem.path) {
        if (viewModel.currentMediaItem.value?.path != mediaItem.path) {
            viewModel.playMedia(mediaItem)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Core Media3 Video Player Surface
        if (exoPlayer != null) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false // We render our own beautiful custom Compose controls
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Invisible Gestures Handler Layer (Volume, Brightness and Double-Tap Seeker)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    // Double-tap seeking gestures
                    detectTapGestures(
                        onTap = {
                            if (!isLocked) showControls = !showControls
                        },
                        onDoubleTap = { offset ->
                            if (!isLocked) {
                                val halfWidth = size.width / 2f
                                if (offset.x < halfWidth) {
                                    // Rewind 10s
                                    val newPos = (progress - 10000).coerceAtLeast(0L)
                                    viewModel.seekTo(newPos)
                                    gestureOverlayText = "Rewind -10s"
                                } else {
                                    // Fast forward 10s
                                    val newPos = (progress + 10000).coerceAtMost(duration)
                                    viewModel.seekTo(newPos)
                                    gestureOverlayText = "Fast Forward +10s"
                                }
                                coroutineScope.launch {
                                    showGestureIndicator = true
                                    delay(800)
                                    showGestureIndicator = false
                                }
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    // Vertical Swipe Gestures for Brightness/Volume
                    detectVerticalDragGestures { change, dragAmount ->
                        if (!isLocked) {
                            val isLeftHalf = change.position.x < (size.width / 2f)
                            
                            if (isLeftHalf) {
                                // Dynamic Brightness Control
                                val delta = -dragAmount / size.height.toFloat()
                                currentBrightness = (currentBrightness + delta).coerceIn(0.01f, 1.0f)
                                activity?.let { act ->
                                    val lp = act.window.attributes
                                    lp.screenBrightness = currentBrightness
                                    act.window.attributes = lp
                                }
                                val percent = (currentBrightness * 100).toInt()
                                gestureOverlayText = "Brightness: $percent%"
                            } else {
                                // Dynamic Volume Control
                                val delta = if (dragAmount > 0) -1 else 1
                                currentVolume = (currentVolume + delta).coerceIn(0, maxVolume)
                                audioManager.setStreamVolume(
                                    AudioManager.STREAM_MUSIC,
                                    currentVolume,
                                    0
                                )
                                val percent = ((currentVolume.toFloat() / maxVolume) * 100).toInt()
                                gestureOverlayText = "Volume: $percent%"
                            }

                            coroutineScope.launch {
                                showGestureIndicator = true
                                delay(1200)
                                showGestureIndicator = false
                            }
                        }
                    }
                }
        )

        // Visual HUD Action Controls
        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
            ) {
                // Header Panel
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Text(
                        text = mediaItem.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
                    )

                    if (!isLocked) {
                        IconButton(onClick = { showAudioBoostDialog = true }) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Audio Boost", tint = CyberCyan)
                        }
                        IconButton(onClick = { showSpeedDialog = true }) {
                            Icon(Icons.Default.Speed, contentDescription = "Playback Speed", tint = Color.White)
                        }
                        IconButton(onClick = {
                            activity?.enterPictureInPictureMode()
                        }) {
                            Icon(Icons.Default.PictureInPicture, contentDescription = "PiP Mode", tint = Color.White)
                        }
                    }
                }

                // Mid Lock Screen Toggle button
                IconButton(
                    onClick = { isLocked = !isLocked },
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(16.dp)
                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = "Lock controls",
                        tint = if (isLocked) Color.Red else CyberCyan
                    )
                }

                // Footer Panel (Only visible if unlocked)
                if (!isLocked) {
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .padding(16.dp)
                    ) {
                        // Slider Progress Track
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = formatTime(progress),
                                color = Color.White,
                                fontSize = 12.sp
                            )
                            Slider(
                                value = progress.toFloat(),
                                onValueChange = { viewModel.seekTo(it.toLong()) },
                                valueRange = 0f..(duration.toFloat().coerceAtLeast(1f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp)
                                    .testTag("video_progress_slider"),
                                colors = SliderDefaults.colors(
                                    thumbColor = CyberCyan,
                                    activeTrackColor = CyberCyan,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                                )
                            )
                            Text(
                                text = formatTime(duration),
                                color = Color.White,
                                fontSize = 12.sp
                            )
                        }

                        // Bottom Player Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { viewModel.skipToPrevious() }) {
                                Icon(Icons.Default.SkipPrevious, "Prev", tint = Color.White, modifier = Modifier.size(32.dp))
                            }

                            IconButton(
                                onClick = {
                                    val amount = (progress - 10000).coerceAtLeast(0L)
                                    viewModel.seekTo(amount)
                                }
                            ) {
                                Icon(Icons.Default.Replay10, "-10s", tint = Color.White, modifier = Modifier.size(32.dp))
                            }

                            IconButton(
                                onClick = {
                                    if (isPlaying) viewModel.pausePlayback() else viewModel.resumePlayback()
                                },
                                modifier = Modifier
                                    .size(60.dp)
                                    .background(CyberCyan, CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "PlayPause",
                                    tint = Color.Black,
                                    modifier = Modifier.size(36.dp)
                                )
                            }

                            IconButton(
                                onClick = {
                                    val amount = (progress + 10000).coerceAtMost(duration)
                                    viewModel.seekTo(amount)
                                }
                            ) {
                                Icon(Icons.Default.Forward10, "+10s", tint = Color.White, modifier = Modifier.size(32.dp))
                            }

                            IconButton(onClick = { viewModel.skipToNext() }) {
                                Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(32.dp))
                            }
                        }
                    }
                }
            }
        }

        // Gesture Action overlay pop-ups
        AnimatedVisibility(
            visible = showGestureIndicator,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.7f))
                    .padding(horizontal = 24.dp, vertical = 12.dp)
            ) {
                Text(
                    text = gestureOverlayText,
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }

        // Playback speed Selector dialog
        if (showSpeedDialog) {
            AlertDialog(
                onDismissRequest = { showSpeedDialog = false },
                title = { Text("Playback Speed", color = Color.White) },
                text = {
                    Column {
                        val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f, 4.0f)
                        speeds.forEach { speed ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.setPlaybackSpeed(speed)
                                        showSpeedDialog = false
                                    }
                                    .padding(vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "${speed}x", color = Color.White)
                                if (playbackSpeed == speed) {
                                    Icon(Icons.Default.Check, null, tint = CyberCyan)
                                }
                            }
                        }
                    }
                },
                confirmButton = {},
                containerColor = CarbonSurface
            )
        }

        // Audio Boost config dialog
        if (showAudioBoostDialog) {
            AlertDialog(
                onDismissRequest = { showAudioBoostDialog = false },
                title = { Text("Audio Boost (Loudness)", color = Color.White) },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Boost: ${audioBoost.toInt()}%",
                            color = CyberCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Slider(
                            value = audioBoost,
                            onValueChange = { viewModel.updateAudioBoost(it) },
                            valueRange = 0f..100f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberCyan,
                                activeTrackColor = CyberCyan
                            )
                        )
                        Text(
                            text = "Boost volume safely beyond maximum limits utilizing physical hardware decoders.",
                            fontSize = 11.sp,
                            color = MutedText
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAudioBoostDialog = false }) {
                        Text("Done", color = CyberCyan)
                    }
                },
                containerColor = CarbonSurface
            )
        }
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "00:00"
    val seconds = (ms / 1000) % 60
    val minutes = (ms / (1000 * 60)) % 60
    val hours = (ms / (1000 * 60 * 60)) % 24
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
