package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.AdsShowcaseScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.MusicPlayerScreen
import com.example.ui.screens.NetworkStreamScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.screens.VaultScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.MediaViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val navController = rememberNavController()
                val viewModel: MediaViewModel = viewModel()
                val currentMedia by viewModel.currentMediaItem.collectAsState()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "library",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        // Main Media Library Dashboard
                        composable("library") {
                            LibraryScreen(
                                viewModel = viewModel,
                                onNavigateToVideo = { item ->
                                    viewModel.playMedia(item)
                                    navController.navigate("video")
                                },
                                onNavigateToMusic = { item ->
                                    viewModel.playMedia(item)
                                    navController.navigate("music")
                                },
                                onNavigateToVault = {
                                    navController.navigate("vault")
                                },
                                onNavigateToStream = {
                                    navController.navigate("stream")
                                },
                                onNavigateToAds = {
                                    navController.navigate("ads")
                                }
                            )
                        }

                        // Immersive Video Player Screen
                        composable("video") {
                            val activeItem = currentMedia
                            if (activeItem != null) {
                                VideoPlayerScreen(
                                    viewModel = viewModel,
                                    mediaItem = activeItem,
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    }
                                )
                            } else {
                                navController.navigateUp()
                            }
                        }

                        // Premium Audio Player with Equalizer
                        composable("music") {
                            val activeItem = currentMedia
                            if (activeItem != null) {
                                MusicPlayerScreen(
                                    viewModel = viewModel,
                                    mediaItem = activeItem,
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    }
                                )
                            } else {
                                navController.navigateUp()
                            }
                        }

                        // PIN Locked Private Vault Folder
                        composable("vault") {
                            VaultScreen(
                                viewModel = viewModel,
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }

                        // Direct Network URL Stream Link Player
                        composable("stream") {
                            NetworkStreamScreen(
                                viewModel = viewModel,
                                onPlayVideo = { item ->
                                    viewModel.playMedia(item)
                                    navController.navigate("video")
                                },
                                onPlayMusic = { item ->
                                    viewModel.playMedia(item)
                                    navController.navigate("music")
                                },
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }

                        // Monetization & premium gold features
                        composable("ads") {
                            AdsShowcaseScreen(
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
